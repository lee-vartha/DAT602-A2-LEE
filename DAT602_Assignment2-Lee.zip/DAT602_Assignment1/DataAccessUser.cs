﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic.ApplicationServices;
using MySql.Data.MySqlClient;

namespace DAT602_Assignment1
{
    public class DataAccessUser : DataAccessObject
    {
        public static string CurrentUsername { get; set; } // getting the current username


        // the login result would be the message and whether the user is an admin
        public class LoginResult
        {
            public string Message { get; set; }
            public bool IsAdmin { get; set; }
        }



        // testing the connection for users
        public string TestUserConnection()
        {
            try
            {
                DataAccessUser.mySqlConnection.Open();
                return "Connection successful for the user";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DataAccessUser.mySqlConnection.Close();
            }
        }



       // method to add a new user into the system
        public string AddUserName(string pUsername, string pPassword)
        {
            List<MySqlParameter> parameters = new List<MySqlParameter>(); // getting the list of parameters

            var usernameParam = new MySqlParameter("@pUsername", MySqlDbType.VarChar, 50); // the username parameter
            var passwordParam = new MySqlParameter("@pPassword", MySqlDbType.VarChar, 50); // the password parameter
            usernameParam.Value = pUsername;
            passwordParam.Value = pPassword;
            parameters.Add(usernameParam);
            parameters.Add(passwordParam);

            var dataSet = MySqlHelper.ExecuteDataset(DataAccessUser.mySqlConnection, "call AddUsername(@pUsername, @pPassword)", parameters.ToArray()); // calling the add username method in sql

            // Expecting one table with one row
            return (dataSet.Tables[0].Rows[0])["MESSAGE"].ToString();
        }


        // getting a list of all the players (found in the list box in the lobby)
        public List<Player> GetAllPlayers()
        {
            var players = new List<Player>(); // all player objects would be added to a new list

            using (var connection = new MySqlConnection(connectionString)) // getting the connection string
            {
                connection.Open();
                using (var command = new MySqlCommand("GetAllPlayers", connection)) // calling the sql method to get all players
                {
                    command.CommandType = CommandType.StoredProcedure;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            players.Add(new Player
                            {
                                Username = reader["Username"].ToString()
                            });
                        }
                    }
                }
            }

            return players;
        }

   

        // getting all online players (list in lobby)
        public List<Player> GetOnlinePlayers()
        {
            List<Player> onlinePlayers = new List<Player>(); 
            DataAccessObject dataAccessObject = new DataAccessObject();
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open(); 
                using (var cmd = new MySqlCommand("SELECT Username FROM Player WHERE Status = 'ONLINE'", connection)) // the command to get all online players -- if status is offline then they wont be in the list
                {
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Player player = new Player
                            {
                                Username = reader["Username"].ToString()
                            };
                            onlinePlayers.Add(player);
                        }
                    }
                }
            }
            return onlinePlayers;
        }

    


        // the method to login
        public LoginResult Login(string pUsername, string pPassword)
        {
            try
            {
                DataAccessUser.mySqlConnection.Open();
                List<MySqlParameter> parameters = new List<MySqlParameter>();

                // Add parameters for the procedure
                var usernameParam = new MySqlParameter("@pUsername", MySqlDbType.VarChar, 50); // taking the username parameter
                usernameParam.Value = pUsername;
                parameters.Add(usernameParam);

                var passwordParam = new MySqlParameter("@pPassword", MySqlDbType.VarChar, 50); // taking the password parameter
                passwordParam.Value = pPassword;
                parameters.Add(passwordParam);

                var dataSet = MySqlHelper.ExecuteDataset(DataAccessUser.mySqlConnection, "call Login(@pUsername, @pPassword)", parameters.ToArray()); // calling the sql method to login

                if (dataSet.Tables.Count > 0 && dataSet.Tables[0].Rows.Count > 0)
                {
                    bool isAdmin = Convert.ToBoolean(dataSet.Tables[0].Rows[0]["IsAdmin"]); // checking if the user is an admin

                    string message = dataSet.Tables[0].Rows[0]["Message"].ToString();

                    return new LoginResult // if the user is admin 
                    {
                        Message = message,
                        IsAdmin = isAdmin
                    };
                }
                else
                { 
                    return new LoginResult // otherwise if the user isnt admin
                    {
                        Message = "Login failed, no result returned.",
                        IsAdmin = false
                    };
                }
            }
            catch (Exception ex)
            {
                return new LoginResult
                {
                    Message = $"Error: {ex.Message}",
                    IsAdmin = false
                };
            }
            finally
            {
                DataAccessUser.mySqlConnection.Close();
            }
        }



        // the method to logout
        public void Logout(string pUsername)
        {
            try
            {
                using (var connection = new MySqlConnection(connectionString)) // connecting to the database
                {
                    connection.Open();
                    using (var cmd = new MySqlCommand("Logout", connection)) // calling the sql method to logout
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@pUsername", pUsername); // adding the username parameter
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Logout is successful");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error logging out: {ex.Message}");
            }
        }



        // the method to delete yourself (rather than the admin doing it)
        public string DeleteSelf(string pUsername)
        {
            List<MySqlParameter> parameters = new List<MySqlParameter>();
            var playerParam = new MySqlParameter("@pUsername", MySqlDbType.VarChar, 50) // getting your username
            {
                Value = pUsername
            };
            parameters.Add(playerParam);

            var dataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "CALL DeleteUser(@pUsername)", parameters.ToArray()); // calling the sql method to delete user

            return dataSet.Tables[0].Rows[0]["Message"].ToString();
        }



        // the method to update user
        public void Update(string pUsername, string pPassword)
        {
            List<MySqlParameter> sqlParameters = new List<MySqlParameter>
            {
                new MySqlParameter()
                {
                    ParameterName = "@Username",
                    MySqlDbType = MySqlDbType.VarChar,
                    Size = 50,
                    Value = pUsername
                },
                new MySqlParameter()
                {
                    ParameterName = "@Password",
                    MySqlDbType = MySqlDbType.VarChar,
                    Size = 50,
                    Value = pPassword
                },
            };
            string SqlCall = "CALL UpdateUser(@pUsername, @pPassword)";

            var aDataSet = MySqlHelper.ExecuteDataset(mySqlConnection, SqlCall, sqlParameters.ToArray());
        }



    }
}
