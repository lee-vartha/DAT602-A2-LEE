﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Mysqlx.Notice.Warning.Types;

namespace DAT602_Assignment1
{
    public class Tile
    {
        public int TileID { get; set; } // tile id
        public int row { get; set; } // tile row
        public int col { get; set; } // tile column
        public int flower { get; set; } // tile flower item
        public int rock { get; set; } // tile rock item

        public int empty { get; set; } // tile empty item
        public TileType Type { get; set; } // tile type
        public Image TileImage { get; set; } // tile image
        public int FlowerTilesSpanned { get; set; } // flower tiles spanned
        public int ItemCount { get; set; } // item count


        // an enumeration of all the tile type (items)
        public enum TileType
        {
            Flower,
            Rock,
            Empty
        }

        // constructor for tile
        public Tile(int tileID, TileType type, int flower = 0, int rock = 0, int empty = 0)
        {
            TileID = tileID;
            Type = type;
            this.flower = flower;
            this.rock = rock;
            this.empty = empty;
        }

        public Tile()
        {
            TileID = 0;
            Type = TileType.Empty;
            flower = 0;
            rock = 0;
            empty = 1;
        }

        // setting the tile type
        public void SetTileType(string itemType, int count)
        {
            ItemCount = count;
            Type = itemType switch
            {
                "Flower" => TileType.Flower,
                "Rock" => TileType.Rock,
                _ => TileType.Empty
            };
        }



        

        public static List<Tile> lcTiles = new List<Tile>();


    }
}
