using MySql.Data.MySqlClient;
using Org.BouncyCastle.Bcpg.OpenPgp;
using System.Windows.Forms;
using static DAT602_Assignment1.DataAccessUser;

namespace DAT602_Assignment1
{
    public partial class GameLogin : Form
    {
        private GameLobby gameLobby;
        private MySql.Data.MySqlClient.MySqlConnection MySqlConnection;

        public GameLogin()
        {
            InitializeComponent();
        }

        // on load - testing the connection to the db
        private void GameLogin_Load(object sender, EventArgs e)
        {
            DataAccessUser dataAccessUser = new DataAccessUser();
            string result = dataAccessUser.TestUserConnection();
            MessageBox.Show(result);

        }


        // attempts made (password)
        int attempts = 0;


        // when the 'confirm' button is clicked
        private void btn_confirm_Click(object sender, EventArgs e)
        {
            try
            {
                // getting the username and password fields
                string username = txt_username.Text;
                string password = txt_password.Text;

                // accessing the db
                DataAccessUser dataAccessUser = new DataAccessUser();
                LoginResult loginResult = dataAccessUser.Login(username, password); // referencing the login method in the DAO 

                // if the user is logged in (if the message from the db is seen)
                if (loginResult.Message == "Logged In")
                {
                    // open the lobby (and passing the 'is admin' boolean
                    GameLobby gameLobby = new GameLobby(loginResult.IsAdmin, username);
                    gameLobby.Show();
                    this.Hide();
                }
                // otherwise if the database shows 'locked out' then open the game lock form
                else if (loginResult.Message == "Locked Out")
                {
                    GameLock gameLock = new GameLock();
                    gameLock.Show();
                    this.Hide();
                }
                else
                {
                    // in general - if the password is wrong, we add attempts and display them
                    attempts++;
                    DisplayErrorMessages();
                    if (attempts == 4) // if there are 3 attempts and the buttonis clicked for the fourth time, open the gamelock
                    {
                        GameLock gameLock = new GameLock();
                        gameLock.Show();
                        this.Hide();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        // if the 'switch' button was clicked (if they want to go to the register form instead)
        private void btn_switch_Click(object sender, EventArgs e)
        {
            GameRegister gameRegister = new GameRegister(gameLobby);
            gameRegister.Show();
            this.Hide();
        }

   
        // displaying error messages (making the hidden labels shown based on what number of attempts have been made
        private void DisplayErrorMessages()
        {
            lbl_error1.Visible = attempts == 1; // if someone has gotten their password wrong 1 time (' three more attempts ')
            lbl_error2.Visible = attempts == 2; // if someone has gotten their password wrong 2 times (' two more attempts ')
            lbl_error3.Visible = attempts == 3; // if someone has gotten their password wrong 3 times (' one more attempts' ) -- if they click it one more time then they get locked out
        }

        
    }


}

