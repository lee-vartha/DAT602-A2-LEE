﻿namespace DAT602_Assignment1
{
    partial class GameStart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameStart));
            pictureBox1 = new PictureBox();
            btn_start = new Button();
            btn_exit = new Button();
            credit_lbl = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-9, 7);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(384, 275);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // btn_start
            // 
            btn_start.BackColor = Color.Wheat;
            btn_start.FlatAppearance.BorderColor = Color.SandyBrown;
            btn_start.FlatStyle = FlatStyle.Flat;
            btn_start.Font = new Font("SimSun", 12F);
            btn_start.ForeColor = Color.Sienna;
            btn_start.Location = new Point(89, 281);
            btn_start.Name = "btn_start";
            btn_start.Size = new Size(189, 31);
            btn_start.TabIndex = 0;
            btn_start.Text = "Start";
            btn_start.UseVisualStyleBackColor = false;
            btn_start.Click += btn_start_Click;
            // 
            // btn_exit
            // 
            btn_exit.BackColor = Color.Wheat;
            btn_exit.FlatAppearance.BorderColor = Color.SandyBrown;
            btn_exit.FlatStyle = FlatStyle.Flat;
            btn_exit.Font = new Font("SimSun", 12F);
            btn_exit.ForeColor = Color.Sienna;
            btn_exit.Location = new Point(89, 325);
            btn_exit.Name = "btn_exit";
            btn_exit.Size = new Size(189, 31);
            btn_exit.TabIndex = 1;
            btn_exit.Text = "Exit";
            btn_exit.UseVisualStyleBackColor = false;
            btn_exit.Click += btn_exit_Click;
            // 
            // credit_lbl
            // 
            credit_lbl.AutoSize = true;
            credit_lbl.BackColor = Color.Transparent;
            credit_lbl.Font = new Font("Segoe UI", 7F);
            credit_lbl.ForeColor = Color.Sienna;
            credit_lbl.Location = new Point(89, 397);
            credit_lbl.Name = "credit_lbl";
            credit_lbl.Size = new Size(186, 15);
            credit_lbl.TabIndex = 6;
            credit_lbl.Text = "Designed by Lee Vartha - MMXXIV";
            // 
            // GameStart
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Frame_1__3_;
            ClientSize = new Size(370, 421);
            Controls.Add(credit_lbl);
            Controls.Add(btn_exit);
            Controls.Add(btn_start);
            Controls.Add(pictureBox1);
            Name = "GameStart";
            Text = "GameStart";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Button btn_start;
        private Button btn_exit;
        private Label credit_lbl;
    }
}