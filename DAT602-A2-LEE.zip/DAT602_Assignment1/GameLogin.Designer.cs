﻿namespace DAT602_Assignment1
{
    partial class GameLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameLogin));
            txt_username = new TextBox();
            login_lbl = new Label();
            btn_confirm = new Button();
            password_lbl = new Label();
            txt_password = new TextBox();
            username_lbl = new Label();
            btn_switch = new Button();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            lbl_error1 = new Label();
            lbl_error2 = new Label();
            lbl_error3 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txt_username
            // 
            txt_username.Font = new Font("SimSun", 11F);
            txt_username.ForeColor = Color.Sienna;
            txt_username.Location = new Point(40, 119);
            txt_username.Name = "txt_username";
            txt_username.Size = new Size(285, 28);
            txt_username.TabIndex = 0;
            txt_username.Text = "Enter Username...";
            // 
            // login_lbl
            // 
            login_lbl.AutoSize = true;
            login_lbl.BackColor = Color.Transparent;
            login_lbl.Font = new Font("SimSun", 18F);
            login_lbl.ForeColor = Color.Sienna;
            login_lbl.Location = new Point(140, 45);
            login_lbl.Name = "login_lbl";
            login_lbl.Size = new Size(88, 30);
            login_lbl.TabIndex = 1;
            login_lbl.Text = "Login";
            // 
            // btn_confirm
            // 
            btn_confirm.BackColor = Color.Wheat;
            btn_confirm.FlatAppearance.BorderColor = Color.SandyBrown;
            btn_confirm.FlatStyle = FlatStyle.Flat;
            btn_confirm.Font = new Font("SimSun", 12F);
            btn_confirm.ForeColor = Color.Sienna;
            btn_confirm.Location = new Point(89, 267);
            btn_confirm.Name = "btn_confirm";
            btn_confirm.Size = new Size(189, 31);
            btn_confirm.TabIndex = 2;
            btn_confirm.Text = "Confirm";
            btn_confirm.UseVisualStyleBackColor = false;
            btn_confirm.Click += btn_confirm_Click;
            // 
            // password_lbl
            // 
            password_lbl.AutoSize = true;
            password_lbl.BackColor = Color.Transparent;
            password_lbl.Font = new Font("SimSun", 10F);
            password_lbl.ForeColor = Color.Sienna;
            password_lbl.Location = new Point(39, 186);
            password_lbl.Name = "password_lbl";
            password_lbl.Size = new Size(80, 17);
            password_lbl.TabIndex = 5;
            password_lbl.Text = "Password";
            // 
            // txt_password
            // 
            txt_password.Font = new Font("Segoe UI", 9F);
            txt_password.ForeColor = Color.Sienna;
            txt_password.Location = new Point(40, 206);
            txt_password.Name = "txt_password";
            txt_password.PasswordChar = '*';
            txt_password.Size = new Size(285, 27);
            txt_password.TabIndex = 1;
            // 
            // username_lbl
            // 
            username_lbl.AutoSize = true;
            username_lbl.BackColor = Color.Transparent;
            username_lbl.Font = new Font("SimSun", 10F);
            username_lbl.ForeColor = Color.Sienna;
            username_lbl.Location = new Point(40, 99);
            username_lbl.Name = "username_lbl";
            username_lbl.Size = new Size(80, 17);
            username_lbl.TabIndex = 7;
            username_lbl.Text = "Username";
            // 
            // btn_switch
            // 
            btn_switch.BackColor = Color.Wheat;
            btn_switch.FlatAppearance.BorderColor = Color.SandyBrown;
            btn_switch.FlatStyle = FlatStyle.Flat;
            btn_switch.Font = new Font("SimSun", 8.25F);
            btn_switch.ForeColor = Color.Sienna;
            btn_switch.Location = new Point(40, 378);
            btn_switch.Name = "btn_switch";
            btn_switch.Size = new Size(285, 25);
            btn_switch.TabIndex = 3;
            btn_switch.Text = "Click to sign up to the game";
            btn_switch.UseVisualStyleBackColor = false;
            btn_switch.Click += btn_switch_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(24, 304);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(48, 46);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.Wheat;
            button1.FlatAppearance.BorderColor = Color.SandyBrown;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("SimSun", 7F);
            button1.ForeColor = Color.Sienna;
            button1.Location = new Point(12, 12);
            button1.Name = "button1";
            button1.Size = new Size(45, 27);
            button1.TabIndex = 4;
            button1.Text = "Back";
            button1.UseVisualStyleBackColor = false;
            // 
            // lbl_error1
            // 
            lbl_error1.AutoSize = true;
            lbl_error1.BackColor = Color.Transparent;
            lbl_error1.Font = new Font("SimSun", 6F);
            lbl_error1.ForeColor = Color.Sienna;
            lbl_error1.Location = new Point(43, 236);
            lbl_error1.Name = "lbl_error1";
            lbl_error1.Size = new Size(190, 10);
            lbl_error1.TabIndex = 11;
            lbl_error1.Text = "Incorrect Password! [3 More Attempts]";
            lbl_error1.Visible = false;
            // 
            // lbl_error2
            // 
            lbl_error2.AutoSize = true;
            lbl_error2.BackColor = Color.Transparent;
            lbl_error2.Font = new Font("SimSun", 6F);
            lbl_error2.ForeColor = Color.Sienna;
            lbl_error2.Location = new Point(43, 236);
            lbl_error2.Name = "lbl_error2";
            lbl_error2.Size = new Size(190, 10);
            lbl_error2.TabIndex = 12;
            lbl_error2.Text = "Incorrect Password! [2 More Attempts]";
            lbl_error2.Visible = false;
            // 
            // lbl_error3
            // 
            lbl_error3.AutoSize = true;
            lbl_error3.BackColor = Color.Transparent;
            lbl_error3.Font = new Font("SimSun", 6F);
            lbl_error3.ForeColor = Color.Sienna;
            lbl_error3.Location = new Point(40, 236);
            lbl_error3.Name = "lbl_error3";
            lbl_error3.Size = new Size(190, 10);
            lbl_error3.TabIndex = 13;
            lbl_error3.Text = "Incorrect Password! [1 More Attempts]";
            lbl_error3.Visible = false;
            // 
            // GameLogin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(370, 419);
            Controls.Add(lbl_error3);
            Controls.Add(lbl_error2);
            Controls.Add(lbl_error1);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Controls.Add(btn_switch);
            Controls.Add(username_lbl);
            Controls.Add(txt_password);
            Controls.Add(password_lbl);
            Controls.Add(btn_confirm);
            Controls.Add(login_lbl);
            Controls.Add(txt_username);
            DoubleBuffered = true;
            Name = "GameLogin";
            Text = "Bees and Blossom";
            Load += GameLogin_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txt_username;
        private Label login_lbl;
        private Button btn_confirm;
        private Label password_lbl;
        private TextBox txt_password;
        private Label username_lbl;
        private Button btn_switch;
        private PictureBox pictureBox1;
        private Button button1;
        private Label lbl_error1;
        private Label lbl_error2;
        private Label lbl_error3;
    }
}
