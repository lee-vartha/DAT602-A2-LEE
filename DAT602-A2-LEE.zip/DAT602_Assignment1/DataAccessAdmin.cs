﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace DAT602_Assignment1
{
    public class DataAccessAdmin : DataAccessObject // encapsulation
    {


        // testing the connection to the database
        public string TestAdminConnection()
        {
            try
            {
                DataAccessAdmin.mySqlConnection.Open();
                return "Connection successful for the admin"; // returning a message if the connection worked
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DataAccessAdmin.mySqlConnection.Close();
            }
        }


        // isnt in use since for the meantime i linked it to the regular 'register' page
        public void CreateUser(Player player)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                using (var cmd = new MySqlCommand("INSERT INTO Player (UserName, Password, Status) VALUES (@Username, @Password, 'OFFLINE')", connection)) // calling the sql method
                {
                    cmd.Parameters.AddWithValue("@Username", player.Username);
                    cmd.Parameters.AddWithValue("@Password", player.Password); 
                    cmd.ExecuteNonQuery();
                }
            }
        }


        // updating the user - not working yet
        public void UpdateUser(Player player)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open(); 
                using (var cmd = new MySqlCommand("UPDATE Player SET Password = @Password WHERE Username = @Username", connection)) // calling the sql method to update the user
                {
                    cmd.Parameters.AddWithValue("@Username", player.Username);
                    cmd.Parameters.AddWithValue("@Password", player.Password);

                    cmd.ExecuteNonQuery();
                }
            }
        }



        // deleting a user
        public string DeleteUser(string pUserName)
        {
            List<MySqlParameter> parameters = new List<MySqlParameter>(); // creating a list of parameters
            var playerParam = new MySqlParameter("@pUsername", MySqlDbType.VarChar, 50) // creating a new parameter for the username
            {
                Value = pUserName // the value being the username
            };
            parameters.Add(playerParam); 

            var dataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "CALL DeleteUser(@pUsername)", parameters.ToArray()); // calling the sql method to delete the user

            return dataSet.Tables[0].Rows[0]["Message"].ToString(); // returning a message
        }

    }
}
