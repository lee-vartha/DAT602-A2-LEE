﻿namespace DAT602_Assignment1
{
    partial class GamePlay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            pictureBox100 = new PictureBox();
            pictureBox101 = new PictureBox();
            pictureBox103 = new PictureBox();
            pictureBox116 = new PictureBox();
            boardPanel = new Panel();
            InventoryBox = new ListBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox100).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox101).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox103).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox116).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Wheat;
            button1.ForeColor = Color.Sienna;
            button1.Location = new Point(15, 19);
            button1.Name = "button1";
            button1.Size = new Size(53, 42);
            button1.TabIndex = 0;
            button1.Text = "Exit";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // pictureBox100
            // 
            pictureBox100.Location = new Point(35, 182);
            pictureBox100.Name = "pictureBox100";
            pictureBox100.Size = new Size(298, 107);
            pictureBox100.TabIndex = 100;
            pictureBox100.TabStop = false;
            // 
            // pictureBox101
            // 
            pictureBox101.Location = new Point(35, 295);
            pictureBox101.Name = "pictureBox101";
            pictureBox101.Size = new Size(298, 48);
            pictureBox101.TabIndex = 101;
            pictureBox101.TabStop = false;
            // 
            // pictureBox103
            // 
            pictureBox103.Location = new Point(34, 472);
            pictureBox103.Name = "pictureBox103";
            pictureBox103.Size = new Size(298, 132);
            pictureBox103.TabIndex = 103;
            pictureBox103.TabStop = false;
            // 
            // pictureBox116
            // 
            pictureBox116.BackColor = Color.Transparent;
            pictureBox116.BackgroundImage = Properties.Resources.download;
            pictureBox116.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox116.Location = new Point(68, 12);
            pictureBox116.Name = "pictureBox116";
            pictureBox116.Size = new Size(227, 170);
            pictureBox116.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox116.TabIndex = 206;
            pictureBox116.TabStop = false;
            // 
            // boardPanel
            // 
            boardPanel.Location = new Point(361, 19);
            boardPanel.Name = "boardPanel";
            boardPanel.Size = new Size(634, 585);
            boardPanel.TabIndex = 209;
            // 
            // InventoryBox
            // 
            InventoryBox.BackColor = Color.OldLace;
            InventoryBox.Font = new Font("SimSun", 8F);
            InventoryBox.FormattingEnabled = true;
            InventoryBox.ItemHeight = 13;
            InventoryBox.Location = new Point(35, 348);
            InventoryBox.Name = "InventoryBox";
            InventoryBox.Size = new Size(297, 121);
            InventoryBox.TabIndex = 210;
            // 
            // GamePlay
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Frame_1__3_;
            ClientSize = new Size(1039, 616);
            Controls.Add(InventoryBox);
            Controls.Add(boardPanel);
            Controls.Add(button1);
            Controls.Add(pictureBox116);
            Controls.Add(pictureBox103);
            Controls.Add(pictureBox101);
            Controls.Add(pictureBox100);
            Name = "GamePlay";
            Text = "GamePlay";
            Load += GamePlay_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox100).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox101).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox103).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox116).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox100;
        private PictureBox pictureBox101;
        private PictureBox pictureBox103;
        private PictureBox pictureBox116;
        private Panel boardPanel;
        private ListBox InventoryBox;
    }
}