﻿namespace DAT602_Assignment1
{
    partial class GamePlay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            button1 = new Button();
            pictureBox116 = new PictureBox();
            boardPanel = new Panel();
            pictureBox2 = new PictureBox();
            InventoryBox = new ListBox();
            label1 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            timeLabel = new Label();
            label3 = new Label();
            StatusBox = new ListBox();
            pictureBox4 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox116).BeginInit();
            boardPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Wheat;
            button1.ForeColor = Color.Sienna;
            button1.Location = new Point(15, 19);
            button1.Name = "button1";
            button1.Size = new Size(53, 42);
            button1.TabIndex = 0;
            button1.Text = "Exit";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // pictureBox116
            // 
            pictureBox116.BackColor = Color.Transparent;
            pictureBox116.BackgroundImage = Properties.Resources.logo;
            pictureBox116.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox116.BorderStyle = BorderStyle.FixedSingle;
            pictureBox116.Location = new Point(67, 20);
            pictureBox116.Name = "pictureBox116";
            pictureBox116.Size = new Size(227, 170);
            pictureBox116.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox116.TabIndex = 206;
            pictureBox116.TabStop = false;
            // 
            // boardPanel
            // 
            boardPanel.Controls.Add(pictureBox4);
            boardPanel.Controls.Add(pictureBox2);
            boardPanel.Location = new Point(361, 19);
            boardPanel.Name = "boardPanel";
            boardPanel.Size = new Size(634, 585);
            boardPanel.TabIndex = 209;
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = Properties.Resources.image;
            pictureBox2.Image = Properties.Resources.image_63;
            pictureBox2.Location = new Point(192, 1);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(56, 54);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 215;
            pictureBox2.TabStop = false;
            // 
            // InventoryBox
            // 
            InventoryBox.BackColor = Color.OldLace;
            InventoryBox.Font = new Font("SimSun", 13F);
            InventoryBox.FormattingEnabled = true;
            InventoryBox.ItemHeight = 22;
            InventoryBox.Location = new Point(35, 446);
            InventoryBox.Name = "InventoryBox";
            InventoryBox.Size = new Size(297, 114);
            InventoryBox.TabIndex = 210;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("SimSun", 9F);
            label1.Location = new Point(38, 429);
            label1.Name = "label1";
            label1.Size = new Size(87, 15);
            label1.TabIndex = 211;
            label1.Text = "Inventory:";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // timeLabel
            // 
            timeLabel.AutoSize = true;
            timeLabel.BackColor = Color.Transparent;
            timeLabel.Font = new Font("SimSun", 18F);
            timeLabel.ForeColor = Color.Sienna;
            timeLabel.Location = new Point(134, 218);
            timeLabel.Name = "timeLabel";
            timeLabel.Size = new Size(28, 30);
            timeLabel.TabIndex = 212;
            timeLabel.Text = " ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("SimSun", 9F);
            label3.Location = new Point(37, 266);
            label3.Name = "label3";
            label3.Size = new Size(63, 15);
            label3.TabIndex = 213;
            label3.Text = "Status:";
            // 
            // StatusBox
            // 
            StatusBox.BackColor = Color.OldLace;
            StatusBox.Font = new Font("SimSun", 13F);
            StatusBox.FormattingEnabled = true;
            StatusBox.ItemHeight = 22;
            StatusBox.Location = new Point(35, 286);
            StatusBox.Name = "StatusBox";
            StatusBox.Size = new Size(297, 114);
            StatusBox.TabIndex = 214;
            // 
            // pictureBox4
            // 
            pictureBox4.BackgroundImage = Properties.Resources.image;
            pictureBox4.Image = Properties.Resources.image_63;
            pictureBox4.Location = new Point(381, 3);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(56, 54);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 217;
            pictureBox4.TabStop = false;
            // 
            // GamePlay
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.full_background;
            ClientSize = new Size(1039, 616);
            Controls.Add(StatusBox);
            Controls.Add(label3);
            Controls.Add(timeLabel);
            Controls.Add(label1);
            Controls.Add(InventoryBox);
            Controls.Add(button1);
            Controls.Add(pictureBox116);
            Controls.Add(boardPanel);
            Name = "GamePlay";
            Text = "GamePlay";
            Load += GamePlay_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox116).EndInit();
            boardPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion


        private Button button1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox116;
        private Panel boardPanel;
        private ListBox InventoryBox;
        private Label label1;
        private Label label2;
        private Label timeLabel;
        private Label label3;
        private ListBox StatusBox;
        private PictureBox pictureBox2;
        private PictureBox pictureBox4;
    }
}