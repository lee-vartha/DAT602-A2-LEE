﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static DAT602_Assignment1.GameLobby;

namespace DAT602_Assignment1
{
    public partial class GameAdmin : Form
    {
        private GameLobby gameLobby;
        public GameAdmin(GameLobby lobby)
        {
            this.gameLobby = lobby;
            InitializeComponent();


        }

        // on load (checking connection)
        private void GameAdmin_Load(object sender, EventArgs e)
        {
            DataAccessAdmin dataAccessAdmin = new DataAccessAdmin();
            string result = dataAccessAdmin.TestAdminConnection();
            MessageBox.Show(result);

            LoadListOfPlayers();
            LoadActiveGames();

        }



        // creating a player entry control
        public class PlayerEntryControl : UserControl
        {
            private Label playerNameLabel;

            public PlayerEntryControl(string playerName)
            {
                playerNameLabel = new Label
                {
                    Text = playerName,
                    AutoSize = false, // Disable AutoSize to control the size manually
                    Size = new Size(464, 41), // Set size slightly smaller to fit within the control
                    BorderStyle = BorderStyle.FixedSingle,
                    FlatStyle = FlatStyle.Flat,
                    ForeColor = Color.Sienna,
                    BackColor = Color.Wheat,

                };

                this.Controls.Add(playerNameLabel);

            }
        }


        // if the 'back button' is clicked
        private void back_btn_Click(object sender, EventArgs e)
        {
            GameLobby gameLobby = new GameLobby(); // go back to the lobby
            gameLobby.Show();
            this.Hide();
        }



        // loading the list of players (all that are registered in the system, not just who is online
        private void LoadListOfPlayers()
        {
            try
            {
                DataAccessUser dataAccessUser = new DataAccessUser(); // accessing the DAO for the user
                List<Player> allPlayers = dataAccessUser.GetAllPlayers();

                PlayerListBox.Items.Clear(); // clearing the list box in case of any previous players no longer in system

                foreach (var Player in allPlayers)
                {
                    string PlayersDetails = $"{Player.Username}"; ;
                    PlayerListBox.Items.Add(PlayersDetails);
                }
            }
            catch
            {
                MessageBox.Show("Error loading players");
            }
        }



        // when the 'create user' button is clicked
        private void createUser_btn_Click(object sender, EventArgs e)
        {
            try // open the register page
            {
                GameRegister gameRegister = new GameRegister(gameLobby);
                gameRegister.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening signup page: {ex.Message}");
            }
        }



        // when the 'edit selected user' button is clicked
        private void editUser_btn_Click(object sender, EventArgs e)
        {
            if (PlayerListBox.SelectedItem != null)
            {
                string selectedUsername = PlayerListBox.SelectedItem.ToString(); // the selected username is whatever was selected in the list box
                Player selectedPlayer = Player.lcPlayers.FirstOrDefault(p => p.Username == selectedUsername);

                if (selectedPlayer != null)
                {
                    AdminEdit adminEdit = new AdminEdit(selectedPlayer);
                    adminEdit.Show();
                    this.Hide();

                    LoadListOfPlayers();//load player list
                }
            }
            else
            {
                MessageBox.Show("Please select a player to delete.");//no player selected
            }



        }


        // if the 'delete selected user' button is clicked
        private void deleteUser_btn_Click(object sender, EventArgs e)
        {
            if (PlayerListBox.SelectedItem != null)
            {

                string selectedUser = PlayerListBox.SelectedItem.ToString(); // selected user is found in the list box
                string[] splitItem = selectedUser.Split(','); 
                string selectedPlayer = splitItem[0].Split(':')[0].Trim();

                DialogResult result = MessageBox.Show($"Are you sure you want to delete player {selectedPlayer} ?", "Delete Player", MessageBoxButtons.YesNo); // popup

                if (result == DialogResult.Yes)//if yes
                {
                    DataAccessAdmin dataAccess = new DataAccessAdmin();//instance of admin DAO
                    string response = dataAccess.DeleteUser(selectedPlayer);//call method to delete plaer
                    MessageBox.Show(response);//response from DAO

                    LoadListOfPlayers();//load player list
                }
            }
            else
            {
                MessageBox.Show("Please select a player to delete.");//no player selected
            }

        }


        // loading all active games (seen in a list box)
        public void LoadActiveGames()
        {
            try
            {
                DataAccessGame dataAccess = new DataAccessGame(); // accessing the DAO for the game
                List<Game> activeGames = dataAccess.GetActiveGames();

                LiveGamesBox.Items.Clear();

                if (activeGames != null & activeGames.Count > 0)
                {
                    foreach (var game in activeGames)
                    {
                        string gameDetails = $"{game.GameID} - {game.Players} players - {game.StartTime} - {game.Status}";
                        LiveGamesBox.Items.Add(gameDetails);
                    }

                }
                else
                {
                    LiveGamesBox.Items.Add("No games");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading games");
            }
        }



        // if the 'kill selected game' button is clicked
        private void killGame_btn_Click(object sender, EventArgs e)
        {
            if (LiveGamesBox.SelectedItem != null)
            {
                string selectedGameID = LiveGamesBox.SelectedItem.ToString();
                string[] splitItem = selectedGameID.Split(',');

                string selectedGame = splitItem[0].Split(':')[1].Trim(); // extracting the game ID

                if (int.TryParse(selectedGame, out int gameID)) // converting the ID to an int
                {
                    DialogResult result = MessageBox.Show($"Are you sure you want to delete game {gameID}?", "Kill Game", MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes) // if yes
                    {
                        DataAccessGame dataAccess = new DataAccessGame(); // instance of admin DAO
                        string response = dataAccess.DeleteGame(gameID); // Pass gameID as int
                        MessageBox.Show(response); // response from DAO

                        LoadListOfPlayers(); // load player list
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Game ID format."); // handle invalid format
                }
            }
            else
            {
                MessageBox.Show("Please select a game to delete."); // no game selected
            }
        }
    }
}
