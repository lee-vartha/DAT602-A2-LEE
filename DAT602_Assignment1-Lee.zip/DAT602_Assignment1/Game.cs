﻿using DAT602_Assignment1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAT602_Assignment1
{
    public class Game
    {
        public int GameID { get; set; }
        public int MapID { get; set; }
        public string Status { get; set; }
        public int Players { get; set; }
        public string Player1 { get; set; }
        public string Player2 { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int ScoreRecord { get; set; }

        public override string ToString()
        {
            return $"ID:{GameID} Status:{Status}";
        }
    }
}
