﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace DAT602_Assignment1
{
    public class DataAccessGame : DataAccessObject
    {

        public string TestGameConnection()
        {
            try
            {
                DataAccessGame.mySqlConnection.Open();
                return "Connection successful for the game";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DataAccessGame.mySqlConnection.Close();
            }
        }

        public string MakeBoard(int pMaxRows, int pMaxCols)
        {
            List<MySqlParameter> parameters = new List<MySqlParameter>();
            var maxRowsParam = new MySqlParameter("@pMaxRows", MySqlDbType.Int32);
            maxRowsParam.Value = pMaxRows;
            parameters.Add(maxRowsParam);

            var maxColsParam = new MySqlParameter("@pMaxCols", MySqlDbType.Int32);
            maxColsParam.Value = pMaxCols;
            parameters.Add(maxColsParam);

            var dataSet = MySqlHelper.ExecuteDataset(DataAccessGame.mySqlConnection, "call make_a_board(@pMaxRows, @pMaxCols)", parameters.ToArray());

            return (dataSet.Tables[0].Rows[0])["MESSAGE"].ToString();
        }



        public List<Tile> GetAllTiles(GamePlay theForm)
        {
            List<Tile> lcTiles = new List<Tile>();

            var aDataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "call GetAllTiles()");
            var enumTiles = System.Data.DataTableExtensions.AsEnumerable(aDataSet.Tables[0]);

            // If the current tiles list is empty make a new list otherwise just update
            if (Tile.lcTiles.Count == 0)
            {
                lcTiles = new List<Tile>();

                lcTiles = (from aResult in enumTiles
                           select
                              new Tile
                              {
                                  id = Convert.ToInt32(aResult["id"]),
                                  row = Convert.ToInt32(aResult["row"]),
                                  col = Convert.ToInt32(aResult["col"]),
                                  flower = Convert.ToInt32(aResult["flower"]),
                                  rock = Convert.ToInt32(aResult["rock"])

                              }).ToList();
            }
            else
            {
                foreach (var aResult in enumTiles)
                {
                    // Only update the parts of the Tile that change = do not make a new tile
                    int id_offset = Convert.ToInt32(aResult["id"]) - 1;
                    Tile.lcTiles[id_offset].flower = Convert.ToInt32(aResult["flower"]);
                    Tile.lcTiles[id_offset].rock = Convert.ToInt32(aResult["rock"]);
                }
            }

            return lcTiles;

        }


        public string JoinGame(int gamenow, string CurrentUsername)
        {
            List<MySqlParameter> p = new List<MySqlParameter>();
            var gParam = new MySqlParameter("@pGameID", MySqlDbType.VarChar, 50)
            {
                Value = gamenow
            };
            p.Add(gParam);
            var uParam = new MySqlParameter("@pCurrentUsername", MySqlDbType.VarChar, 50)
            {
                Value = CurrentUsername
            };
            p.Add(uParam);

            var dataSet = MySqlHelper.ExecuteDataset(DataAccessGame.mySqlConnection, "CALL JoinGame(@pGameID, @pCurrentUsername)", p.ToArray());

            return dataSet.Tables[0].Rows[0]["Message"].ToString();
        }

        public string CreateNewGame(int MapID, string CurrentUsername)
        {
            List<MySqlParameter> p = new List<MySqlParameter>();
            var mParam = new MySqlParameter("@pMapID", MySqlDbType.Int32)
            {
                Value = MapID
            };
            p.Add(mParam); // mParam means map parameter

            var uParam = new MySqlParameter("@pCurrentUsername", MySqlDbType.VarChar, 50)
            {
                Value = CurrentUsername
            };
            p.Add(uParam);

            var dataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "CALL NewGame(@pMapID, @pCurrentUsername);", p.ToArray());

            return dataSet.Tables[0].Rows[0]["Message"].ToString();


        }


     
        
        public List<Game> GetActiveGames()
        {
            List<Game> lcGames = new List<Game>();

            mySqlConnection.Open();

            var aDataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "CALL GetActiveGames()");

            if (aDataSet.Tables.Count > 0 && aDataSet.Tables[0].Rows.Count > 0)
            {
                lcGames = (from aResult in aDataSet.Tables[0].AsEnumerable()
                           select new Game
                           {
                               GameID = Convert.ToInt32(aResult["GameID"]),
                               MapID = Convert.ToInt32(aResult["MapID"]),
                               Status = aResult["Status"].ToString()
                           }).ToList();
            }

            mySqlConnection.Close();
            return lcGames;
        }



    }
}
