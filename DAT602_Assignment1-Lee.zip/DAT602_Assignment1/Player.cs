﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAT602_Assignment1
{
    public delegate void Then();
    public class Player
    {
        public static string CurrentUsername { get; set; }
        public static Player CurrentUser { get; set; }
        public int PlayerID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public int Attempts { get; set; }
        public int TileID { get; set; }


        public static List<Player> lcPlayers = new List<Player>();
        public Boolean Update = false;
        public Then? then;

        


        public void UpdateData()
        {
            if (this.Update == true)
            {
                this.updateData();
                if (this.UserName == Player.CurrentUsername)
                {
                    Player.CurrentUser.Update = false;
                    Player.CurrentUser.UserName = this.UserName;
                    Player.CurrentUser.Password = this.Password;
                }
                this.Update = false;
            }
        }


        private void updateData()
        {
            if (UserName != null && Password != null)
            {
                DataAccessUser dataAccess = new DataAccessUser();
                dataAccess.Update(UserName, Password);
            }
        }
    }
}
