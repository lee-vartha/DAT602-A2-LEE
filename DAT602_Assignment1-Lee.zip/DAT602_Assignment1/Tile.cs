﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Mysqlx.Notice.Warning.Types;

namespace DAT602_Assignment1
{
    public class Tile
    {
        public int id { get; set; }
        public int row { get; set; }
        public int col { get; set; }
        public int flower { get; set; }
        public int rock { get; set; }
        public TileType Type { get; set; }

        public enum TileType
        {
            Empty,
            Flower,
            Rock
        }

        public Tile()
        {
            Type = TileType.Empty;
        }

        public void SetTileType()
        {
            if (flower > 0)
                Type = TileType.Flower;
            else if (rock > 0)
                Type = TileType.Rock;
            else
                Type = TileType.Empty;
        }

        public void ItemOnTile(string itemType, int value)
        {
            if (itemType == "Flower")
            {
                flower = value;
                Type = TileType.Flower;
            } 
            else if (itemType == "Rock")
            {
                rock = value;
                Type = TileType.Rock;
            }
            else
            {
                flower = 0;
                rock = 0;
                Type = TileType.Empty;
            }
        }

        public void EgPictureBox_Click(object sender, EventArgs e)
        {
            PictureBox theOneClicked = (PictureBox)sender;
            MessageBox.Show("I am tile ID " + id.ToString() + ". Flower = " + flower.ToString() + " Rock = " + rock.ToString());
        }

        public static List<Tile> lcTiles = new List<Tile>();


    }
}
