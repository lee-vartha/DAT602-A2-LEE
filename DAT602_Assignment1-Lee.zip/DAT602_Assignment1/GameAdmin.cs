﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static DAT602_Assignment1.GameLobby;

namespace DAT602_Assignment1
{
    public partial class GameAdmin : Form
    {
        private GameLobby gameLobby;
        public GameAdmin(GameLobby lobby)
        {
            this.gameLobby = lobby;
            InitializeComponent();


        }

        private void GameAdmin_Load(object sender, EventArgs e)
        {
            DataAccessAdmin dataAccessAdmin = new DataAccessAdmin();
            string result = dataAccessAdmin.TestAdminConnection();
            MessageBox.Show(result);

            LoadListOfPlayers();

        }




        public class PlayerEntryControl : UserControl
        {
            private Label playerNameLabel;

            public PlayerEntryControl(string playerName)
            {
                playerNameLabel = new Label
                {
                    Text = playerName,
                    AutoSize = false, // Disable AutoSize to control the size manually
                    Size = new Size(464, 41), // Set size slightly smaller to fit within the control
                    BorderStyle = BorderStyle.FixedSingle,
                    FlatStyle = FlatStyle.Flat,
                    ForeColor = Color.Sienna,
                    BackColor = Color.Wheat,

                };

                this.Controls.Add(playerNameLabel);

            }
        }



        private void back_btn_Click(object sender, EventArgs e)
        {
            GameLobby gameLobby = new GameLobby();
            gameLobby.Show();
            this.Hide();
        }

        private void LoadListOfPlayers()
        {
            try
            {
                DataAccessUser dataAccessUser = new DataAccessUser();
                List<Player> allPlayers = dataAccessUser.GetAllPlayers();

                PlayerListBox.Items.Clear();

                foreach (var tblGetUser in allPlayers)
                {
                    string PlayersDetails = $"{tblGetUser.UserName}"; ;
                    PlayerListBox.Items.Add(PlayersDetails);
                }
            }
            catch
            {
                MessageBox.Show("Error loading players");
            }
        }

        private void createUser_btn_Click(object sender, EventArgs e)
        {
            try
            {
                GameRegister gameRegister = new GameRegister(gameLobby);
                gameRegister.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening signup page: {ex.Message}");
            }
        }

        private void editUser_btn_Click(object sender, EventArgs e)
        {
            if (PlayerListBox.SelectedItem != null)
            {
                string selectedUsername = PlayerListBox.SelectedItem.ToString();
                Player selectedPlayer = Player.lcPlayers.FirstOrDefault(p => p.UserName == selectedUsername);

                if (selectedPlayer != null)
                {
                    AdminEdit adminEdit = new AdminEdit(selectedPlayer);
                    adminEdit.Show();
                    this.Hide();

                    LoadListOfPlayers();//load player list
                }
            }
            else
            {
                MessageBox.Show("Please select a player to delete.");//no player selected
            }


         
        }



        private void deleteUser_btn_Click(object sender, EventArgs e)
        {
            if (PlayerListBox.SelectedItem != null)
            {

                string selectedUser = PlayerListBox.SelectedItem.ToString();
                string[] splitItem = selectedUser.Split(',');
                string selectedPlayer = splitItem[0].Split(':')[0].Trim();

                DialogResult result = MessageBox.Show($"Are you sure you want to delete player {selectedPlayer} ?", "Delete Player", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)//if yes
                {
                    DataAccessAdmin dataAccess = new DataAccessAdmin();//instance of admin DAO
                    string response = dataAccess.DeleteUser(selectedPlayer);//call method to delete plaer
                    MessageBox.Show(response);//response from DAO

                    LoadListOfPlayers();//load player list
                }
            }
            else
            {
                MessageBox.Show("Please select a player to delete.");//no player selected
            }

        }

    }
}
