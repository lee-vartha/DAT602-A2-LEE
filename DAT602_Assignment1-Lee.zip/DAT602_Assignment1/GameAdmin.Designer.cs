﻿namespace DAT602_Assignment1
{
    partial class GameAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            flowpnl_live = new FlowLayoutPanel();
            flowLayoutPanel1 = new FlowLayoutPanel();
            killGame_btn = new Button();
            deleteUser_btn = new Button();
            editUser_btn = new Button();
            createUser_btn = new Button();
            label4 = new Label();
            back_btn = new Button();
            PlayerListBox = new ListBox();
            flowpnl_live.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("SimSun", 11F);
            label1.ForeColor = Color.Sienna;
            label1.Location = new Point(189, 83);
            label1.Name = "label1";
            label1.Size = new Size(129, 19);
            label1.TabIndex = 4;
            label1.Text = "Admin Window";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("SimSun", 15F);
            label2.ForeColor = Color.Sienna;
            label2.Location = new Point(146, 48);
            label2.Name = "label2";
            label2.Size = new Size(220, 25);
            label2.TabIndex = 3;
            label2.Text = "Bees and Blossom";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("SimSun", 9F);
            label3.ForeColor = Color.Sienna;
            label3.Location = new Point(22, 100);
            label3.Name = "label3";
            label3.Size = new Size(95, 15);
            label3.TabIndex = 30;
            label3.Text = "Live Games:";
            // 
            // flowpnl_live
            // 
            flowpnl_live.Controls.Add(flowLayoutPanel1);
            flowpnl_live.Location = new Point(19, 118);
            flowpnl_live.Name = "flowpnl_live";
            flowpnl_live.Size = new Size(250, 230);
            flowpnl_live.TabIndex = 29;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel1.Location = new Point(3, 3);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(250, 125);
            flowLayoutPanel1.TabIndex = 0;
            // 
            // killGame_btn
            // 
            killGame_btn.BackColor = Color.Wheat;
            killGame_btn.FlatAppearance.BorderColor = Color.SandyBrown;
            killGame_btn.FlatStyle = FlatStyle.Flat;
            killGame_btn.Font = new Font("SimSun", 10F);
            killGame_btn.ForeColor = Color.Sienna;
            killGame_btn.Location = new Point(291, 121);
            killGame_btn.Name = "killGame_btn";
            killGame_btn.Size = new Size(210, 41);
            killGame_btn.TabIndex = 31;
            killGame_btn.Text = "Kill Selected Game";
            killGame_btn.UseVisualStyleBackColor = false;
            // 
            // deleteUser_btn
            // 
            deleteUser_btn.BackColor = Color.Wheat;
            deleteUser_btn.FlatAppearance.BorderColor = Color.SandyBrown;
            deleteUser_btn.FlatStyle = FlatStyle.Flat;
            deleteUser_btn.Font = new Font("SimSun", 10F);
            deleteUser_btn.ForeColor = Color.Sienna;
            deleteUser_btn.Location = new Point(291, 307);
            deleteUser_btn.Name = "deleteUser_btn";
            deleteUser_btn.Size = new Size(210, 41);
            deleteUser_btn.TabIndex = 32;
            deleteUser_btn.Text = "Delete Selected User";
            deleteUser_btn.UseVisualStyleBackColor = false;
            deleteUser_btn.Click += deleteUser_btn_Click;
            // 
            // editUser_btn
            // 
            editUser_btn.BackColor = Color.Wheat;
            editUser_btn.FlatAppearance.BorderColor = Color.SandyBrown;
            editUser_btn.FlatStyle = FlatStyle.Flat;
            editUser_btn.Font = new Font("SimSun", 10F);
            editUser_btn.ForeColor = Color.Sienna;
            editUser_btn.Location = new Point(291, 260);
            editUser_btn.Name = "editUser_btn";
            editUser_btn.Size = new Size(210, 41);
            editUser_btn.TabIndex = 33;
            editUser_btn.Text = "Edit Selected User";
            editUser_btn.UseVisualStyleBackColor = false;
            editUser_btn.Click += editUser_btn_Click;
            // 
            // createUser_btn
            // 
            createUser_btn.BackColor = Color.Wheat;
            createUser_btn.FlatAppearance.BorderColor = Color.SandyBrown;
            createUser_btn.FlatStyle = FlatStyle.Flat;
            createUser_btn.Font = new Font("SimSun", 10F);
            createUser_btn.ForeColor = Color.Sienna;
            createUser_btn.Location = new Point(291, 213);
            createUser_btn.Name = "createUser_btn";
            createUser_btn.Size = new Size(210, 41);
            createUser_btn.TabIndex = 34;
            createUser_btn.Text = "Create New User";
            createUser_btn.UseVisualStyleBackColor = false;
            createUser_btn.Click += createUser_btn_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("SimSun", 9F);
            label4.ForeColor = Color.Sienna;
            label4.Location = new Point(22, 374);
            label4.Name = "label4";
            label4.Size = new Size(159, 15);
            label4.TabIndex = 36;
            label4.Text = "Registered Players:";
            // 
            // back_btn
            // 
            back_btn.BackColor = Color.Wheat;
            back_btn.FlatAppearance.BorderColor = Color.SandyBrown;
            back_btn.FlatStyle = FlatStyle.Flat;
            back_btn.Font = new Font("SimSun", 8F);
            back_btn.ForeColor = Color.Sienna;
            back_btn.Location = new Point(18, 12);
            back_btn.Name = "back_btn";
            back_btn.Size = new Size(69, 29);
            back_btn.TabIndex = 37;
            back_btn.Text = "Back";
            back_btn.UseVisualStyleBackColor = false;
            back_btn.Click += back_btn_Click;
            // 
            // PlayerListBox
            // 
            PlayerListBox.BackColor = Color.OldLace;
            PlayerListBox.Font = new Font("SimSun", 10F);
            PlayerListBox.FormattingEnabled = true;
            PlayerListBox.ItemHeight = 17;
            PlayerListBox.Location = new Point(19, 403);
            PlayerListBox.Name = "PlayerListBox";
            PlayerListBox.Size = new Size(476, 157);
            PlayerListBox.TabIndex = 38;
            // 
            // GameAdmin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Frame_1__3_;
            ClientSize = new Size(513, 589);
            Controls.Add(PlayerListBox);
            Controls.Add(back_btn);
            Controls.Add(label4);
            Controls.Add(createUser_btn);
            Controls.Add(editUser_btn);
            Controls.Add(deleteUser_btn);
            Controls.Add(killGame_btn);
            Controls.Add(label3);
            Controls.Add(flowpnl_live);
            Controls.Add(label1);
            Controls.Add(label2);
            Name = "GameAdmin";
            Text = "X";
            Load += GameAdmin_Load;
            flowpnl_live.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private FlowLayoutPanel flowpnl_live;
        private FlowLayoutPanel flowLayoutPanel1;
        private Button killGame_btn;
        private Button deleteUser_btn;
        private Button editUser_btn;
        private Button createUser_btn;
        private Label label4;
        private Button back_btn;
        private ListBox PlayerListBox;
    }
}