﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic.ApplicationServices;
using MySql.Data.MySqlClient;

namespace DAT602_Assignment1
{
    public class DataAccessUser : DataAccessObject
    {
        public static string CurrentUserName { get; set; }

        public class LoginResult
        {
            public string Message { get; set; }
            public bool IsAdmin { get; set; }
        }


        public string TestUserConnection()
        {
            try
            {
                DataAccessUser.mySqlConnection.Open();
                return "Connection successful for the user";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DataAccessUser.mySqlConnection.Close();
            }
        }



       

        public string AddUserName(string pUserName, string pPassword)
        {
            List<MySqlParameter> parameters = new List<MySqlParameter>();
            var usernameParam = new MySqlParameter("@pUserName", MySqlDbType.VarChar, 50);
            var passwordParam = new MySqlParameter("@pPassword", MySqlDbType.VarChar, 50);
            usernameParam.Value = pUserName;
            passwordParam.Value = pPassword;
            parameters.Add(usernameParam);
            parameters.Add(passwordParam);

            var dataSet = MySqlHelper.ExecuteDataset(DataAccessUser.mySqlConnection, "call AddUserName(@pUserName, @pPassword)", parameters.ToArray());

            // Expecting one table with one row
            return (dataSet.Tables[0].Rows[0])["MESSAGE"].ToString();
        }


        public List<Player> GetAllPlayers()
        {
            var players = new List<Player>();

            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new MySqlCommand("GetAllPlayers", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            players.Add(new Player
                            {
                                UserName = reader["UserName"].ToString()
                            });
                        }
                    }
                }
            }

            return players;
        }

   
        public List<Player> GetOnlinePlayers()
        {
            List<Player> onlinePlayers = new List<Player>();
            DataAccessObject dataAccessObject = new DataAccessObject();
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                using (var cmd = new MySqlCommand("SELECT UserName FROM tblGetUser WHERE Status = 'ONLINE'", connection))
                {
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Player player = new Player
                            {
                                UserName = reader["UserName"].ToString()
                            };
                            onlinePlayers.Add(player);
                        }
                    }
                }
            }
            return onlinePlayers;
        }

    


        public LoginResult Login(string pUserName, string pPassword)
        {
            try
            {
                DataAccessUser.mySqlConnection.Open();
                List<MySqlParameter> parameters = new List<MySqlParameter>();

                // Add parameters for the procedure
                var usernameParam = new MySqlParameter("@pUserName", MySqlDbType.VarChar, 50);
                usernameParam.Value = pUserName;
                parameters.Add(usernameParam);

                var passwordParam = new MySqlParameter("@pPassword", MySqlDbType.VarChar, 50);
                passwordParam.Value = pPassword;
                parameters.Add(passwordParam);

                var dataSet = MySqlHelper.ExecuteDataset(DataAccessUser.mySqlConnection, "call Login(@pUserName, @pPassword)", parameters.ToArray());

                if (dataSet.Tables.Count > 0 && dataSet.Tables[0].Rows.Count > 0)
                {
                    // Ensure you're handling the conversion properly in C#
                    bool isAdmin = Convert.ToBoolean(dataSet.Tables[0].Rows[0]["IsAdmin"]);

                    string message = dataSet.Tables[0].Rows[0]["Message"].ToString();

                    return new LoginResult
                    {
                        Message = message,
                        IsAdmin = isAdmin
                    };
                }
                else
                {
                    return new LoginResult
                    {
                        Message = "Login failed, no result returned.",
                        IsAdmin = false
                    };
                }
            }
            catch (Exception ex)
            {
                return new LoginResult
                {
                    Message = $"Error: {ex.Message}",
                    IsAdmin = false
                };
            }
            finally
            {
                DataAccessUser.mySqlConnection.Close();
            }
        }


        public void Logout(string pUserName)
        {
            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    using (var cmd = new MySqlCommand("Logout", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@pUserName", pUserName);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Logout is successful");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error logging out: {ex.Message}");
            }
        }


        public string DeleteSelf(string pUserName)
        {
            List<MySqlParameter> parameters = new List<MySqlParameter>();
            var playerParam = new MySqlParameter("@pUserName", MySqlDbType.VarChar, 50)
            {
                Value = pUserName
            };
            parameters.Add(playerParam);

            var dataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "CALL DeleteUser(@pUserName)", parameters.ToArray());

            return dataSet.Tables[0].Rows[0]["Message"].ToString();
        }



        public void Update(string pUserName, string pPassword)
        {
            List<MySqlParameter> sqlParameters = new List<MySqlParameter>
            {
                new MySqlParameter()
                {
                    ParameterName = "@Username",
                    MySqlDbType = MySqlDbType.VarChar,
                    Size = 50,
                    Value = pUserName
                },
                new MySqlParameter()
                {
                    ParameterName = "@Password",
                    MySqlDbType = MySqlDbType.VarChar,
                    Size = 50,
                    Value = pPassword
                },
            };
            string SqlCall = "CALL UpdateUser(@pUsername, @pPassword)";

            var aDataSet = MySqlHelper.ExecuteDataset(mySqlConnection, SqlCall, sqlParameters.ToArray());
        }



    }
}
