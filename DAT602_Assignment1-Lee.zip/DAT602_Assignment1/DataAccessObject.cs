﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAT602_Assignment1
{
    public class DataAccessObject
    {
        public static string connectionString
        {
            get { return "Server=localhost; Port=3306; Database=gamedb; Uid=admin; password=pass;"; }
        }

        private static MySqlConnection _mySqlConnection = null;
        protected static MySqlConnection mySqlConnection
        {
            get
            {
                if (_mySqlConnection == null)
                {
                    _mySqlConnection = new MySqlConnection(connectionString);
                }

                return _mySqlConnection;

            }
        }
    }
}
