using MySql.Data.MySqlClient;
using Org.BouncyCastle.Bcpg.OpenPgp;
using System.Windows.Forms;
using static DAT602_Assignment1.DataAccessUser;

namespace DAT602_Assignment1
{
    public partial class GameLogin : Form
    {
        private GameLobby gameLobby;
        private MySql.Data.MySqlClient.MySqlConnection MySqlConnection;

        public GameLogin()
        {
            InitializeComponent();
        }

        private void GameLogin_Load(object sender, EventArgs e)
        {
            DataAccessUser dataAccessUser = new DataAccessUser();
            string result = dataAccessUser.TestUserConnection();
            MessageBox.Show(result);

        }


        int attempts = 0;

        private void btn_confirm_Click(object sender, EventArgs e)
        {
            try
            {
                string username = txt_username.Text;
                string password = txt_password.Text;

                DataAccessUser dataAccessUser = new DataAccessUser();
                LoginResult loginResult = dataAccessUser.Login(username, password);

                if (loginResult.Message == "Logged In")
                {
                    GameLobby gameLobby = new GameLobby(loginResult.IsAdmin, username);
                    gameLobby.Show();
                    this.Hide();
                }
                else if (loginResult.Message == "Locked Out")
                {
                    GameLock gameLock = new GameLock();
                    gameLock.Show();
                    this.Hide();
                }
                else
                {
                    attempts++;
                    DisplayErrorMessages();
                    if (attempts == 4)
                    {
                        GameLock gameLock = new GameLock();
                        gameLock.Show();
                        this.Hide();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btn_switch_Click(object sender, EventArgs e)
        {
            GameRegister gameRegister = new GameRegister(gameLobby);
            gameRegister.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GameStart gameStart = new GameStart();
            gameStart.Show();
            this.Hide();
        }

        private void DisplayErrorMessages()
        {
            lbl_error1.Visible = attempts == 1;
            lbl_error2.Visible = attempts == 2;
            lbl_error3.Visible = attempts == 3;
        }

        
    }






}

