﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace DAT602_Assignment1
{
    public partial class GamePlay : Form
    {
        private const int Rows = 10;
        private const int Columns = 10;

        List<Player> lcPlayers = new List<Player>();
        List<Tile> lcTiles = new List<Tile>();


        public GamePlay()
        {
            InitializeComponent();
            InitializeGameBoard();

            DataAccessUser dbAccess = new DataAccessUser();
            DataAccessGame dbAccessGame = new DataAccessGame();

            lcPlayers = dbAccess.GetAllPlayers();
            lcTiles = dbAccessGame.GetAllTiles(this);

            foreach (var tile in lcTiles)
            {
                PictureBox currentTilePic = new PictureBox();
                currentTilePic.Width = 20;
                currentTilePic.Height = 20;
                currentTilePic.BackColor = Color.Tomato;
                currentTilePic.Location = new Point(tile.col * (currentTilePic.Width + 1), tile.row * (currentTilePic.Height + 1));
                currentTilePic.Click += new System.EventHandler(tile.EgPictureBox_Click);


            }
        }

        private void InitializeGameBoard()
        {
            int tileWidth = boardPanel.Width / Columns;
            int tileHeight = boardPanel.Height / Rows;

            for (int row = 0; row < Rows; row++)
            {
                for (int col = 0; col < Columns; col++)
                {
                    PictureBox tile = new PictureBox
                    {
                        Width = tileWidth - 2,
                        Height = tileHeight - 2,
                        BorderStyle = BorderStyle.FixedSingle,
                        Location = new Point(col * tileWidth, row * tileHeight)
                    };

                    Tile currentTile = lcTiles.FirstOrDefault(t => t.row == row && t.col == col);
                    if (currentTile != null)
                    {
                        currentTile.SetTileType();


                        tile.Tag = currentTile;
                        tile.Click += Tile_Click;

                        switch (currentTile.Type)
                        {
                            case Tile.TileType.Flower:
                                tile.BackColor = Color.Pink;
                                break;
                            case Tile.TileType.Rock:
                                tile.BackColor = Color.Gray;
                                break;
                            default:
                                tile.BackColor = Color.LightSeaGreen;
                                break;
                        }
                    }
                    else
                    {
                        tile.BackColor = Color.LightSeaGreen;
                    }
                    boardPanel.Controls.Add(tile);  

                }
            }
        }


        private void Tile_Click(object? sender, EventArgs e)
        {
            PictureBox clickedTile = sender as PictureBox;
            if (clickedTile != null && clickedTile.Tag is Tile tileData)
            {
                tileData.ItemOnTile("Flower", 5);

                switch (tileData.Type)
                {
                    case Tile.TileType.Flower:
                        clickedTile.BackColor = Color.Pink;
                        break;
                    case Tile.TileType.Rock:
                        clickedTile.BackColor = Color.Gray;
                        break;
                    default:
                        clickedTile.BackColor = Color.LightSeaGreen;
                        break;
                }

                MessageBox.Show($"Tile ID: {tileData.id}, Type: {tileData.Type}, Flower: {tileData.flower}, Rock: {tileData.rock}");
            }
        }



        private void GamePlay_Load(object sender, EventArgs e)
        {
            DataAccessGame dataAccessGame = new DataAccessGame();
            string result = dataAccessGame.TestGameConnection();
            MessageBox.Show(result);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GameLobby gameLobby = new GameLobby();
            gameLobby.Show();
            this.Hide();
        }

        private void boardPanel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
