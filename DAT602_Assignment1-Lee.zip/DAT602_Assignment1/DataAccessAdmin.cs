﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace DAT602_Assignment1
{
    public class DataAccessAdmin : DataAccessObject
    {


        public string TestAdminConnection()
        {
            try
            {
                DataAccessAdmin.mySqlConnection.Open();
                return "Connection successful for the admin";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DataAccessAdmin.mySqlConnection.Close();
            }
        }


        public void CreateUser(Player player)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                using (var cmd = new MySqlCommand("INSERT INTO tblGetUser (UserName, Password, Status) VALUES (@UserName, @Password, 'OFFLINE')", connection))
                {
                    cmd.Parameters.AddWithValue("@UserName", player.UserName);
                    cmd.Parameters.AddWithValue("@Password", player.Password); // Hash the password before saving
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void UpdateUser(Player player)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                using (var cmd = new MySqlCommand("UPDATE tblGetUser SET Password = @Password WHERE UserName = @UserName", connection))
                {
                    cmd.Parameters.AddWithValue("@UserName", player.UserName);
                    cmd.Parameters.AddWithValue("@Password", player.Password);

                    cmd.ExecuteNonQuery();
                }
            }
        }



        public string DeleteUser(string pUserName)
        {
            List<MySqlParameter> parameters = new List<MySqlParameter>();
            var playerParam = new MySqlParameter("@pUserName", MySqlDbType.VarChar, 50)
            {
                Value = pUserName
            };
            parameters.Add(playerParam);

            var dataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "CALL DeleteUser(@pUserName)", parameters.ToArray());

            return dataSet.Tables[0].Rows[0]["Message"].ToString();
        }

    }
}
