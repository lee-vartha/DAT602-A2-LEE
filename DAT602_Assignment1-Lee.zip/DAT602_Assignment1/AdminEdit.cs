﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAT602_Assignment1
{
    public partial class AdminEdit : Form
    {

        private Player player;

        private string currentUsername;
        public AdminEdit(Player selectedPlayer)
        {
            InitializeComponent();
            player = selectedPlayer;
            ShowUser();
            DisplayCurrentUser();
        }

        private void ShowUser()
        {
            txt_username.Text = player.UserName;
            txt_password.Text = player.Password;
        }


        private void UpdateUser()
        {
            player.UserName = txt_username.Text;
            player.Password = txt_password.Text;
        }

        private void DisplayCurrentUser()
        {
            try
            {
                listBox1.Items.Clear();

                listBox1.Items.Add(currentUsername);
            }
            catch (Exception Ex)
            {
                MessageBox.Show($"Error displaying current user: {Ex.Message}");
            }
        }

        private void btn_confirm_Click(object sender, EventArgs e)
        {
            UpdateUser();
        }
    }

}
